#!/bin/bash

# Log file for errors
Errorlogfile="errors.log"

# Recursive function to search for a keyword in a directory and its subdirectories
search_directory() {
    local dir="$1"
    local keyword="$2"

    for file in "$dir"/*; do
        if [ -d "$file" ]; then
            search_directory "$file" "$keyword"  # Recursive call for directories
        elif [ -f "$file" ]; then
            if grep -qi "$keyword" "$file"; then
                echo "Found '$keyword' in: $file"
            fi
        fi
    done
}

# Function to display help menu using a here document
display_help() {
    cat <<END
Usage: $0 [OPTIONS]

Options:
  -d <directory>    Search for files containing a keyword in a directory and its subdirectories.
  -k <keyword>      Specify the keyword to search for.
  -f <file>         Search for the keyword in a specific file.
  --help            Display this help menu.

Examples:
  $0 -d /path/to/dir -k keyword
  $0 -f file.txt -k keyword
END
}

# Function to handle errors
log_error() {
    echo "[ERROR] $1" | tee -a "$Errorlogfile"  # Log to errors.log and display on terminal
}

# Validate inputs using regular expressions
validate_inputs() {
    local keyword="$1"
    local file="$2"
    
    if [[ -z "$keyword" ]]; then
        log_error "Keyword cannot be empty."
        exit 1
    fi

    if [[ ! -z "$file" && ! -f "$file" ]]; then
        log_error "File '$file' does not exist."
        exit 1
    fi
}

# Search for a keyword in a specific file using a here string
search_in_file() {
    local file="$1"
    local keyword="$2"

    # Read the file content and search for the keyword
	file_content=$(cat "$file")
	search_result=$(grep -i "$keyword" <<< "$file_content")

# Check if grep found any matches
if [ -n "$search_result" ]; then
    echo "Keyword '$keyword' found in $file"
else
    echo "Keyword not found in $file"
fi

}

# Parse command-line arguments using getopts
while getopts "d:k:f:-:" opt; do
    case "$opt" in
        d) directory="$OPTARG" ;;
        k) keyword="$OPTARG" ;;
        f) file="$OPTARG" ;;
        -)  # Handle long options
            case "$OPTARG" in
                help) display_help; exit 0 ;;
                *) log_error "Invalid option: --$OPTARG"; exit 1 ;;
            esac
            ;;
        ?) display_help; exit 1 ;;
    esac
done

# Debugging using special parameters
echo "Script Name: $0"
echo "First parameter: $1"
echo "Total Arguments: $#"
echo "Exit Status of Last Command: $?"
echo "All Arguments: $@"

# Validate inputs
validate_inputs "$keyword" "$file"

# Execute appropriate functionality based on arguments
if [[ ! -z "$directory" ]]; then
    if [[ ! -d "$directory" ]]; then
        log_error "Directory '$directory' does not exist."
        exit 1
    fi
    search_directory "$directory" "$keyword"
elif [[ ! -z "$file" ]]; then
    search_in_file "$file" "$keyword"
else
    log_error "Either a directory (-d) or file (-f) must be specified."
    exit 1
fi
