#!/bin/bash

#setting input and output files
Input_file=$1
Output_file="output.txt"

#printing the inputs
echo "Input file:$Input_file"

#clearing the output file
echo "Fetched parameters" > $Output_file

#read input file line by line

while IFS= read -r line; do
#extracting required parameters by grep
Frametime=$(echo "$line" | grep -w "frame.time")
Wlanfctype=$(echo "$line" | grep -w "wlan.fc.type")
Wlanfcsubtype=$(echo "$line" | grep -w "wlan.fc.subtype")

	
#appending output file
if [[ -n "$Frametime" || -n "$Wlanfctype" || -n "$Wlanfcsubtype" ]] 
then
echo "$Frametime" >> $Output_file
echo "$Wlanfctype" >> $Output_file
echo "$Wlanfcsubtype" >> $Output_file
fi
done < "$Input_file"


