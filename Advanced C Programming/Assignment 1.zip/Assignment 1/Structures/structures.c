// Structures

#include <stdio.h>
#include <string.h>

#define MAX_DAYS 7
#define MAX_TASKS 3
#define MAX_TASK_LEN 100

struct Day {
    char dayName[10];
    char tasks[MAX_TASKS][MAX_TASK_LEN];
    int taskCount;
};
void initializeDays(struct Day week[]);
void inputTasks(struct Day week[]);
void displayTasks(const struct Day week[]);

int main() {
    struct Day week[MAX_DAYS];

    initializeDays(week);
    inputTasks(week);
    displayTasks(week);

    return 0;
}
void initializeDays(struct Day week[]) {
    char *dayNames[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

    for (int i = 0; i < MAX_DAYS; i++) {
        strcpy(week[i].dayName, dayNames[i]);
        week[i].taskCount = 0;
    }
}
void inputTasks(struct Day week[]) {
    int dayIndex;
    char task[MAX_TASK_LEN];

    printf("Enter the day number (0 for Monday, 6 for Sunday): ");
    scanf("%d", &dayIndex);

    if (dayIndex < 0 || dayIndex >= MAX_DAYS) {
        printf("Invalid day number!\n");
        return;
    }

    printf("Enter tasks for %s (up to %d tasks):\n", week[dayIndex].dayName, MAX_TASKS);

    for (int i = 0; i < MAX_TASKS; i++) {
        printf("Enter task %d (or 'done' to finish): ", i + 1);
        scanf(" %s", task);

        if (strcmp(task, "done") == 0)
            break;

        strcpy(week[dayIndex].tasks[week[dayIndex].taskCount], task);
        week[dayIndex].taskCount++;
    }
}
void displayTasks(const struct Day week[]) {
    printf("\nWeekly Calendar:\n");

    for (int i = 0; i < MAX_DAYS; i++) {
        printf("%s:\n", week[i].dayName);
        for (int j = 0; j < week[i].taskCount; j++) {
            printf("  - %s\n", week[i].tasks[j]);
        }
        if (week[i].taskCount == 0) {
            printf("  No tasks.\n");
        }
        printf("\n");
    }
}

