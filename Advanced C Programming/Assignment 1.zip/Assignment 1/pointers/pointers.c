//pointers

#include <stdio.h>
void rearrangeEvenOdd(int *arr, int size) {
    int *left = arr, *right = arr + size - 1;
    int temp;

    while (left < right) {
        while (left < right && *left % 2 == 0)
            left++;
        while (left < right && *right % 2 != 0)
            right--;

        if (left < right) {
            temp = *left;
            *left = *right;
            *right = temp;
        }
    }
}

void displayArray(int *arr, int size) {
    for (int i = 0; i < size; i++)
        printf("%d ", *(arr + i));
    printf("\n");
}

int main() {
    int arr[] = {12, 17, 70, 15, 22, 65, 21, 90};
    int size = sizeof(arr) / sizeof(arr[0]);

    printf("Original Array: \n");
    displayArray(arr, size);

    rearrangeEvenOdd(arr, size);

    printf("\nArray after rearranging even and odd: \n");
    displayArray(arr, size);

    return 0;
}

