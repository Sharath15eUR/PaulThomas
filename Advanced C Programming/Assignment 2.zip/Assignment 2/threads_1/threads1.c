//3 Threads parallel

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

// Function for sum of first N primes
void *threadA(void *arg) {
    int N = *(int *)arg;
    int sum = 0, count = 0, num = 2;

    while (count < N) {
        int isPrime = 1;
        for (int i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                isPrime = 0;
                break;
            }
        }
        if (isPrime) {
            sum += num;
            count++;
        }
        num++;
    }

    printf("Thread A: Sum of first %d primes is %d\n", N, sum);
    pthread_exit(NULL);
}
void *threadB(void *arg) {
    for (int i = 0; i < 50; i++) { 
        printf("Thread B: Thread 1 running\n");
        sleep(2);
    }
    pthread_exit(NULL);
}
void *threadC(void *arg) {
    for (int i = 0; i < 33; i++) {
        printf("Thread C: Thread 2 running\n");
        sleep(3);
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t tA, tB, tC;
    int N;
    printf("Enter value of N: ");
    scanf("%d", &N);
    pthread_create(&tA, NULL, threadA, &N);
    pthread_create(&tB, NULL, threadB, NULL);
    pthread_create(&tC, NULL, threadC, NULL);
    pthread_join(tA, NULL);
    pthread_join(tB, NULL);
    pthread_join(tC, NULL);
    printf("All threads completed.\n");

    return 0;
}
