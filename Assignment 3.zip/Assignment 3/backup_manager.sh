#!/bin/bash


# Command-line arguments
NAME_OF_SCRIPTFILE="$0"
SOURCE_DIR="$1"
BACKUP_DIR="$2"
FILE_EXT="$3"

#Printing on screen
echo "The name of script file is $NAME_OF_SCRIPTFILE"
echo "Path to source directory is $SOURCE_DIR"
echo "Path to backup directory is $BACKUP_DIR"
echo "The file extensions taken is $FILE_EXT"

# Environment variable to track the total number of files backed up
export BACKUP_COUNT=0

# Check if the source directory exists
if [ ! -d "$SOURCE_DIR" ]; then
    echo "Error: Source directory '$SOURCE_DIR' does not exist."
    exit 1
fi

# Create the backup directory if it does not exist
if [ ! -d "$BACKUP_DIR" ]; then
    mkdir -p "$BACKUP_DIR" || { echo "Error: Failed to create backup directory '$BACKUP_DIR'."; exit 1; }
fi

# Use globbing to find matching files
FILES=("$SOURCE_DIR"/*"$FILE_EXT")

# Check if there are files to back up
if [ ${#FILES[@]} -eq 0 ]; then
    echo "No files with extension '$FILE_EXT' found in '$SOURCE_DIR'."
    exit 0
fi

# Print file names and sizes before backing up
echo "Files to back up:"
for FILE in "${FILES[@]}"; do
    if [ -f "$FILE" ]; then
        FILE_SIZE=$(stat --printf="%s" "$FILE")
        echo "$(basename "$FILE") - $FILE_SIZE bytes"
    fi
done

# Perform the backup
for FILE in "${FILES[@]}"; do
    if [ -f "$FILE" ]; then
        BASENAME=$(basename "$FILE")
        DEST_FILE="$BACKUP_DIR/$BASENAME"
        
        # Check if the file needs to be copied (overwrite only if the source is newer)
        if [ -f "$DEST_FILE" ]; then
            if [ "$FILE" -nt "$DEST_FILE" ]; then
                cp "$FILE" "$DEST_FILE"
                echo "Updated: $BASENAME"
                BACKUP_COUNT=$((BACKUP_COUNT + 1))
            else
                echo "Skipped: $BASENAME (destination is up-to-date)"
            fi
        else
            cp "$FILE" "$DEST_FILE"
            echo "Copied: $BASENAME"
            BACKUP_COUNT=$((BACKUP_COUNT + 1))
        fi
    fi
done

# Generate the backup report
TOTAL_SIZE=0
for FILE in "${FILES[@]}"; do
    if [ -f "$FILE" ]; then
        FILE_SIZE=$(stat --printf="%s" "$FILE")
        TOTAL_SIZE=$((TOTAL_SIZE + FILE_SIZE))
    fi
done

#creating report file and redirecting the commands to reportfile
REPORT_FILE="$BACKUP_DIR/backup_report.log"
echo "Backup Summary:" >> "$REPORT_FILE"
echo "Total files processed: ${#FILES[@]}" >> "$REPORT_FILE"
echo "Total files backed up: $BACKUP_COUNT" >> "$REPORT_FILE"
echo "Total size of files backed up: $TOTAL_SIZE bytes" >> "$REPORT_FILE"
echo "Backup directory: $BACKUP_DIR" >> "$REPORT_FILE"

